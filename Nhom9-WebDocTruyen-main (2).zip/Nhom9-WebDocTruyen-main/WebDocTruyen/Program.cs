﻿using Microsoft.EntityFrameworkCore;
using System;
using WebDocTruyen.Models;

var builder = WebApplication.CreateBuilder(args);

// 1. Đổi sang AddControllersWithViews() để hỗ trợ View (.cshtml)
builder.Services.AddControllersWithViews();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Đăng ký AppDbContext kết nối SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Đăng ký HttpContextAccessor và Session
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Sắp xếp lại thứ tự Middleware chuẩn xác của ASP.NET Core
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// UseSession bắt buộc phải nằm sau UseRouting và trước UseAuthorization
app.UseSession();
app.UseAuthorization();

// Định tuyến dành riêng cho khu vực Admin (Đặt lên trước route mặc định)
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");

// Định tuyến về Home/Index khi mở web
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();